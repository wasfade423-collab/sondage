-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 05 fév. 2026 à 20:36
-- Version du serveur : 9.1.0
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `afrika`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(30) NOT NULL,
  `pass` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `enqueteur`
--

DROP TABLE IF EXISTS `enqueteur`;
CREATE TABLE IF NOT EXISTS `enqueteur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomEnqt` text NOT NULL,
  `nomQuested` text NOT NULL,
  `prenomQuested` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `resultat`
--

DROP TABLE IF EXISTS `resultat`;
CREATE TABLE IF NOT EXISTS `resultat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `age` varchar(100) NOT NULL,
  `sexe` varchar(10) NOT NULL,
  `secteurActivite` varchar(20) NOT NULL,
  `payVil` varchar(100) NOT NULL,
  `regularite` varchar(255) NOT NULL,
  `epargne` varchar(255) NOT NULL,
  `moyenEpargne` text NOT NULL,
  `epagneParMois` varchar(255) NOT NULL,
  `knowInvest` varchar(30) NOT NULL,
  `ETF` varchar(20) NOT NULL,
  `SimpleInvest` varchar(20) NOT NULL,
  `InvestSmallPrice` varchar(100) NOT NULL,
  `frequence` varchar(100) NOT NULL,
  `rassure` varchar(100) NOT NULL,
  `fk_user` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user` (`fk_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
